import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

public class TestSuit {

    protected static WebDriver driver;

    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "src/test/java/driver/chromedriver.exe");
        // open chrome browser
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get("https://demo.nopcommerce.com/");



        // click on register button

    //  driver.findElement(By.className("ico-register")).click();
        clickOnElement(By.className("ico-register"));


        // enter firstname
       // driver.findElement(By.xpath("//input[@name='FirstName']")).sendKeys("Automation")
        typeText(By.xpath("//input[@name='FirstName']"),"Automation");

        //enter lastname
      //  driver.findElement(By.id("LastName")).sendKeys("LastNameTest");
        typeText(By.id("LastName"),"LastNameTest");

        //enter email
       // driver.findElement(By.id("Email")).sendKeys("charmy@gmail.com");
        typeText(By.id("Email"),"charmy"+randomDate()+"@gmail.com");

        //enter password


       // driver.findElement(By.id("Password")).sendKeys("12345@abc");
        typeText(By.id("Password"),"12345@abc");

        //enter confirm password

      //  driver.findElement(By.id("ConfirmPassword")).sendKeys("12345@abc");
        typeText(By.id("ConfirmPassword"),"12345@abc");


        //enter register
      //  driver.findElement(By.name("register-button")).click();
        clickOnElement(By.name("register-button"));

       // driver.quit();

    }

    public static void clickOnElement(By by){
        driver.findElement(by).click();
    }


    public static void typeText(By by, String text) {

        driver.findElement(by).sendKeys(text);
    }

    public static String randomDate(){
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyyHHmmss");
        return formatter.format(date);


    }
   //  public static void  driverWaits(){
      // WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));

         public static  void  waitForClickbale(int time,By by) {
             WebDriverWait waitForClickbale = new WebDriverWait(driver, Duration.ofSeconds(10));
             waitForClickbale.until(ExpectedConditions.elementToBeClickable(by));

    }

     public  static String getTextFromElement(By by)
     {
        return  driver.findElement(by).getText();
     }
  }


























